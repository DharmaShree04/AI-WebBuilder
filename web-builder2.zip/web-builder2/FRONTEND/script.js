console.log("JS Loaded");

const API = "http://localhost:5000";
const GENERATE_TIMEOUT_MS = 125000;
const ACTIVE_USER_KEY = "activeUserEmail";
const MAX_QUOTA_RETRIES = 1;
let generatedFrontendCode = "";
let generatedBackendCode = "";
let showingCode = false;

function setLoading(isLoading) {
  const loadingState = document.getElementById("loadingState");
  const sendButton = document.querySelector(".send-btn");
  loadingState.style.display = isLoading ? "flex" : "none";
  sendButton.disabled = isLoading;
  sendButton.style.opacity = isLoading ? "0.7" : "1";
  sendButton.style.cursor = isLoading ? "not-allowed" : "pointer";
}
function setLoadingMessage(message) {
  const loadingMessage = document.querySelector("#loadingState p");
  if (loadingMessage) {
    loadingMessage.textContent = message;
  }
}

function showLivePreview() {
  const iframe = document.getElementById("preview");
  const codeBlock = document.getElementById("codeBlock");
  const toggleButton = document.querySelector(".actions button:last-child");

  if (iframe) iframe.style.display = "block";
  if (codeBlock) codeBlock.style.display = "none";
  if (toggleButton) toggleButton.textContent = "Show Code";
  showingCode = false;
}

function moveToLivePreview() {
  const previewSection = document.querySelector(".preview-section");
  if (previewSection) {
    previewSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function showQuotaRetryCountdown(seconds) {
  for (let remaining = seconds; remaining > 0; remaining--) {
    setLoadingMessage(`AI quota reached. Retrying in ${remaining}s...`);
    await wait(1000);
  }
}

function resetWorkspace() {
  generatedFrontendCode = "";
  generatedBackendCode = "";
  showingCode = false;

  const promptInput = document.getElementById("prompt");
  const preview = document.getElementById("preview");
  const codeBlock = document.getElementById("codeBlock");
  const toggleButton = document.querySelector(".actions button:last-child");

  if (promptInput) promptInput.value = "";
  if (preview) {
    preview.style.display = "block";
    preview.srcdoc = "";
  }
  if (codeBlock) {
    codeBlock.style.display = "none";
    codeBlock.textContent = "";
  }
  if (toggleButton) {
    toggleButton.textContent = "Show Code";
  }
}

function setActiveUser(user) {
  if (user && user.email) {
    localStorage.setItem(ACTIVE_USER_KEY, user.email);
  } else {
    localStorage.removeItem(ACTIVE_USER_KEY);
  }
}

/* FORM SWITCH */
function showLogin() {
  document.getElementById("signupForm").style.display = "none";
  document.getElementById("loginForm").style.display = "block";
  document.getElementById("formTitle").innerText = "Login";
}

function showSignup() {
  document.getElementById("signupForm").style.display = "block";
  document.getElementById("loginForm").style.display = "none";
  document.getElementById("formTitle").innerText = "Signup";
}

/* VALIDATION (FIXED) */
function validateEmail(email) {
  return /^[a-zA-Z]+[a-zA-Z0-9]*[0-9]+@gmail\.com$/.test(email);
}

function validatePassword(password) {
  return password.length >= 6;
}

/* SIGNUP */
async function signup() {
  console.log("Signup clicked");

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!validateEmail(email)) {
    alert("Use format: dharma123@gmail.com");
    return;
  }

  if (!validatePassword(password)) {
    alert("Password must be at least 6 characters");
    return;
  }

  try {
    const res = await fetch(`${API}/signup`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ name, email, password })
    });

    const data = await res.json();
    console.log(data);

    if (!res.ok) {
      alert(data.error || "Signup failed");
      return;
    }

    alert(data.message || "Signup successful");

    if (data.message === "Signup successful") {
      showLogin();
      document.getElementById("loginEmail").value = email;
    }
  } catch (err) {
    console.error(err);
    alert("Server not responding");
  }
}

/* LOGIN */
async function login() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  try {
    const res = await fetch(`${API}/login`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (res.ok && data.message === "Login successful") {
      const previousUserEmail = localStorage.getItem(ACTIVE_USER_KEY);
      if (previousUserEmail !== data.user.email) {
        resetWorkspace();
      }
      localStorage.setItem("user", JSON.stringify(data.user));
      setActiveUser(data.user);
      document.getElementById("authCard").style.display = "none";
      document.getElementById("homeCard").style.display = "block";
    } else {
      alert(data.error || "Invalid credentials");
    }
  } catch (err) {
    console.error(err);
    alert("Server error");
  }
}

/* GENERATE */
async function generateUI() {
  const prompt = document.getElementById("prompt").value.trim();

  if (!prompt) {
    alert("Describe the website you want to build first.");
    return;
  }

  try {
    setLoading(true);
    showLivePreview();
    moveToLivePreview();
    let quotaRetryCount = 0;
    let data = null;

    while (true) {
      const controller = new AbortController();
      let timeoutId = setTimeout(() => controller.abort(), GENERATE_TIMEOUT_MS);

      setLoadingMessage("Processing your website request. This may take around 2 minutes...");

      const res = await fetch(`${API}/generate-ai`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      timeoutId = null;

      data = await res.json();

      if (res.status === 429 && data.retryAfterSeconds && quotaRetryCount < MAX_QUOTA_RETRIES) {
        quotaRetryCount += 1;
        await showQuotaRetryCountdown(data.retryAfterSeconds);
        continue;
      }

      if (!res.ok || data.error) {
        if (res.status === 429 && data.retryAfterSeconds) {
          alert(`AI quota reached. Please try again in about ${data.retryAfterSeconds} seconds.`);
          return;
        }

        alert(data.details || data.error || "AI generation failed");
        return;
      }

      break;
    }

    generatedFrontendCode = data.frontendCode || "";
    generatedBackendCode = data.backendCode || "";
    document.getElementById("preview").srcdoc = generatedFrontendCode || "<h1>No frontend returned</h1>";

    const codeBlock = document.getElementById("codeBlock");
    if (showingCode) {
      codeBlock.textContent = buildCombinedCode();
    }
  } catch (err) {
    console.error(err);
    if (err.name === "AbortError") {
      alert("Processing is taking longer than expected. Please try again.");
    } else {
      alert("Server not responding");
    }
  } finally {
    setLoadingMessage("Generating your website. This can take up to 1 minute...");
    setLoading(false);
  }
}
/* SHOW CODE */
function toggleView() {
  const iframe = document.getElementById("preview");
  const codeBlock = document.getElementById("codeBlock");
  const toggleButton = document.querySelector(".actions button:last-child");

  if (!showingCode) {
    iframe.style.display = "none";
    codeBlock.style.display = "block";
    codeBlock.textContent = buildCombinedCode();
    showingCode = true;
    toggleButton.textContent = "Show Preview";
  } else {
    iframe.style.display = "block";
    codeBlock.style.display = "none";
    showingCode = false;
    toggleButton.textContent = "Show Code";
  }
}

/* COPY */
function copyCode() {
  navigator.clipboard.writeText(buildCombinedCode());
  alert("Copied!");
}

/* DOWNLOAD */
function downloadCode() {
  const blob = new Blob([buildCombinedCode()], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "generated-code.txt";
  a.click();
}

/* LOGOUT FIXED */
function logout() {
  resetWorkspace();
  localStorage.removeItem("user");
  setActiveUser(null);
  location.reload();
}

/* AUTO LOGIN */
window.onload = () => {
  const savedUser = localStorage.getItem("user");

  if (savedUser) {
    try {
      const parsedUser = JSON.parse(savedUser);
      const previousUserEmail = localStorage.getItem(ACTIVE_USER_KEY);

      if (previousUserEmail !== parsedUser.email) {
        resetWorkspace();
      }

      setActiveUser(parsedUser);
    } catch (err) {
      console.error(err);
      localStorage.removeItem("user");
      setActiveUser(null);
      resetWorkspace();
      return;
    }

    resetWorkspace();
    document.getElementById("authCard").style.display = "none";
    document.getElementById("homeCard").style.display = "block";
  } else {
    resetWorkspace();
  }
};

/* PASSWORD TOGGLE */
function toggleEye(inputId, eyeId) {
  const input = document.getElementById(inputId);
  const eye = document.getElementById(eyeId);

  eye.style.display = input.value.length > 0 ? "block" : "none";
}

function togglePassword(inputId) {
  const input = document.getElementById(inputId);
  input.type = input.type === "password" ? "text" : "password";
}
function openNewTab() {
  if (!generatedFrontendCode) {
    alert("Generate something first!");
    return;
  }

  const newWindow = window.open("", "_blank");

  if (!newWindow) {
    alert("Popup blocked! Allow popups for this site.");
    return;
  }

  newWindow.document.open();
  newWindow.document.write(generatedFrontendCode);
  newWindow.document.close();
}

/* BUILD COMBINED CODE VIEW */
function buildCombinedCode() {
  const frontend = generatedFrontendCode || "// Frontend not generated yet.";
  const backend = generatedBackendCode
    ? `\n\n// ---------- Backend (Node + Express) ----------\n${generatedBackendCode}`
    : "\n\n// Backend not generated (try generating again).";

  return `<!-- ---------- Frontend (HTML + Tailwind) ---------- -->\n${frontend}${backend}`;
}


