const axios = require("axios");
const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

function getProviderStatus(error) {
  return error?.response?.status || error?.status || error?.cause?.status || null;
}

function getProviderMessage(error) {
  return (
    error?.response?.data?.error?.message ||
    error?.response?.data?.message ||
    error?.message ||
    "Unknown provider error"
  );
}

function createProviderError(provider, error) {
  const status = getProviderStatus(error);
  const wrappedError = new Error(`${provider} failed: ${getProviderMessage(error)}`);
  wrappedError.provider = provider;
  wrappedError.status = status;
  wrappedError.isAuthError = status === 401 || status === 403;
  return wrappedError;
}

async function callGemini(prompt) {
  const model = genAI.getGenerativeModel({
    model: "gemini-2.5-flash-lite",
  });

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    throw createProviderError("Gemini", error);
  }
}

async function callGroq(prompt) {
  try {
    const res = await axios.post(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        model: "llama3-70b-8192",
        messages: [{ role: "user", content: prompt }],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    return res.data.choices[0].message.content;
  } catch (error) {
    throw createProviderError("Groq", error);
  }
}

async function callOpenRouter(prompt) {
  try {
    const res = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "mistralai/mistral-7b-instruct",
        messages: [{ role: "user", content: prompt }],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    return res.data.choices[0].message.content;
  } catch (error) {
    throw createProviderError("OpenRouter", error);
  }
}

async function generateWithFallback(prompt) {
  const providers = [
    ["Gemini", callGemini],
    ["Groq", callGroq],
    ["OpenRouter", callOpenRouter],
  ];
  const errors = [];

  for (const [providerName, providerFn] of providers) {
    try {
      console.log(`Trying ${providerName}...`);
      return await providerFn(prompt);
    } catch (error) {
      errors.push(error);
      console.log(`${providerName} failed -> trying next provider`);
    }
  }

  const allAuthErrors = errors.length > 0 && errors.every((error) => error.isAuthError);
  const finalError = new Error(
    allAuthErrors
      ? "All configured AI providers rejected the request. Check the API keys in backend/.env."
      : errors.map((error) => error.message).join(" | ")
  );

  finalError.code = allAuthErrors ? "AI_AUTH_FAILED" : "AI_FALLBACK_FAILED";
  finalError.status = allAuthErrors ? 502 : errors[0]?.status || 500;
  finalError.providers = errors.map((error) => ({
    provider: error.provider,
    status: error.status,
    message: error.message,
  }));

  throw finalError;
}

module.exports = { generateWithFallback };
