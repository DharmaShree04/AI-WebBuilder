const path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") });
const{ generateWithFallback } = require("./aiFallback");
console.log("Gemini API Key present:", !!process.env.GEMINI_API_KEY);
console.log("Groq API Key present:", !!process.env.GROQ_API_KEY);
console.log("OpenRouter API Key present:", !!process.env.OPENROUTER_API_KEY);
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const app = express();
app.use(cors());
app.use(bodyParser.json());
const PORT = Number(process.env.PORT) || 5000;
function extractSection(content, startMarker, endMarker) {
  const startIndex = content.indexOf(startMarker);
  const endIndex = content.indexOf(endMarker);
  if (startIndex === -1 || endIndex === -1 || endIndex <= startIndex) {
    return "";
  }
  return content.slice(startIndex + startMarker.length, endIndex).trim();
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function getRetryDelayMs(error) {
  const message = error && error.message ? error.message : "";
  const retryInfoMatch = message.match(/retryDelay":"(\d+)s"/i);
  if (retryInfoMatch) {
    return Number(retryInfoMatch[1]) * 1000;
  }
 const textMatch = message.match(/retry in ([\d.]+)s/i);
  if (textMatch) {
    return Math.ceil(Number(textMatch[1]) * 1000);
  }
  return 0;
}
function isQuotaError(error) {
  const message = error && error.message ? error.message : "";
  return message.includes("429 Too Many Requests") || message.toLowerCase().includes("quota exceeded");
}
// PUT YOUR GEMINI API KEY HERE
const db = require("./db");
// Ensure the app schema exists even on a fresh local DB.
const ensureUsersTableSql = `
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);
`;
const ensureGeneratedPagesTableSql = `
CREATE TABLE IF NOT EXISTS generated_pages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  prompt TEXT NOT NULL,
  code LONGTEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
`;
db.query(ensureUsersTableSql, (err) => {
  if (err) console.error("failed to ensure users table:", err);
  else console.log("users table ready");
});
db.query(ensureGeneratedPagesTableSql, (err) => {
  if (err) console.error("failed to ensure generated_pages table:", err);
  else console.log("generated_pages table ready");
});
app.post("/signup", (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Name, email, and password are required" });
  }
  db.query(
    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
    [name, email, password],
    (err, result) => {
      if (err) {
        if (err.code === "ER_DUP_ENTRY") {
          return res.status(409).json({ error: "Email already registered" });
        }
    console.error("Signup DB error:", err);
        return res.status(500).json({ error: "Signup failed" });
      }
      res.json({
        message: "Signup successful",
        user: { id: result.insertId, name, email },
      });
    }
  );
});
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }
  db.query(
    "SELECT id, name, email, password FROM users WHERE email = ? LIMIT 1",
    [email],
    (err, rows) => {
      if (err) {
        console.error("Login DB error:", err);
        return res.status(500).json({ error: "Login failed" });
      }
      if (!rows.length || rows[0].password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      const user = rows[0];
      res.json({
        message: "Login successful",
        user: { id: user.id, name: user.name, email: user.email },
      });
    }
  );
});
app.post("/generate-ai", async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "Prompt is required" });
    }
    const fullPrompt = `
You are an expert product designer, frontend engineer, motion designer, and full-stack AI code generator.
Return ONLY plain text in this exact structure with all four markers present:
---FRONTEND_START---
<!DOCTYPE html>...complete runnable frontend...
---FRONTEND_END---
---BACKEND_START---
const express = require("express");
...complete runnable backend...
---BACKEND_END---
Your job is to generate a polished, interactive, production-style website that feels custom designed, not a generic template.
Frontend rules:
- Output one complete HTML document with valid <!DOCTYPE html>, <head>, <body>, CSS, and JS included.
- Include the Tailwind CDN script in <head>.
- Do not rely on any external assets besides Tailwind.
- Support both full web apps and polished landing pages. If the request sounds promotional, marketing-focused, brand-focused, or startup-focused, generate a complete landing page by default.
- If the design needs imagery, generate it inline using SVG, gradients, patterns, CSS illustrations, or data-URI images so the preview still looks rich without external image URLs.
- Build a visually distinctive UI with a strong concept, not a plain vertical stack of sections.
- Prefer layered layouts, split screens, dashboards, cards, floating panels, sticky controls, timelines, pricing switchers, tabs, accordions, animated stats, modal or drawer interactions, and meaningful calls to action when relevant.
- Include tasteful animations and micro-interactions using CSS and vanilla JS:
  - entrance reveals
  - hover states
  - animated buttons
  - counters, tabs, accordions, filters, sliders, progress indicators, or similar interactive controls when appropriate
- Make the layout responsive for desktop, tablet, and mobile.
- Use strong typography hierarchy, spacing rhythm, shadows, gradients, and contrast.
- Avoid a boring one-column endless-scroll landing page unless the user explicitly asks for one.
- When generating a landing page, include a strong hero section, clear CTA buttons, branded feature sections, social proof or testimonials, product/storytelling blocks, and a strong footer.
- Make buttons and UI controls actually do something in the generated page whenever reasonable.
- Include at least one interactive section that feels app-like or prototyping-tool quality.
- If the prompt is vague, infer a useful product structure, features, and content instead of using placeholder lorem ipsum.
- Use realistic copy, labels, navigation, feature names, and button text based on the request.
- Keep the generated frontend self-contained so it renders correctly inside an iframe preview.
Design quality bar:
- The result should feel closer to a Figma-inspired polished prototype than a classroom demo.
- Vary layout composition and section ordering based on the prompt.
- Use a clear visual identity and avoid repeating the same hero/features/testimonials pattern every time.
- Add motion with restraint: smooth, premium, and purposeful.
- Favor fast generation: keep the page focused and high quality rather than overly huge. A smaller polished result is better than a massive repetitive page.
- If the user does not specify the page type, choose the format that best fits the request and make that decision confidently.
-also keep action buttons and landing pages along wwith smooth animations and interactions to make the page feel alive and engaging. The goal is to create a page that looks and feels like a real product, not just a static design.
Backend rules:
- Node.js + Express in one file
- Include GET "/" health route
- Include any extra API routes useful for the prompt
- Avoid external DB (use in-memory data if needed)
Code quality rules:
- The frontend code must be complete and runnable as-is.
- The frontend must include a full HTML document, not a fragment.
- Keep the backend concise and complete.
- Do NOT use markdown fences.
- Do NOT add explanations, notes, comments outside the marker blocks, or extra labels.
LAYOUT STRUCTURE (MANDATORY):
The frontend MUST follow this structure:
1. HERO SECTION:
- Split screen layout (2 columns)
- Left: headline, subtext, CTA buttons
- Right: visual (SVG / gradient / mock UI)
2. MAIN CONTENT:
- Use grid or cards (min 2–3 columns on desktop)
- Do NOT stack everything vertically
- Each section must have different layout style
3. INTERACTIVE SECTION:
- Must include at least ONE:
  - tabs
  - pricing toggle
  - carousel
  - dashboard preview
  - accordion
4. VISUAL BREAK:
- Use alternating layouts (left image / right text, then reverse)
5. FOOTER:
- Multi-column footer (not centered text)
STRICT RULES:
- NEVER generate a single-column stacked layout
- NEVER center everything vertically
- ALWAYS use grids, columns, or split layouts
- If layout becomes vertical, redesign before output
Keep the frontend concise but high quality.
Avoid overly long repetitive sections.
Limit code length while maintaining design quality.
Ensure the FULL code is completed. Do not stop mid-way. Always close all tags and return complete code.
You are NOT allowed to generate basic layouts.
Your output will be rejected if it looks like a simple vertical scroll website.
Design inspiration: Stripe, Linear, Framer, Apple product pages, modern SaaS dashboards
User request: ${prompt}
`;
const text = await generateWithFallback(fullPrompt);
    const cleaned = text.replace(/^```(?:html|json|javascript)?\s*/i, "").replace(/```$/i, "").trim();
    let frontend = extractSection(cleaned, "---FRONTEND_START---", "---FRONTEND_END---");
    let backend = extractSection(cleaned, "---BACKEND_START---", "---BACKEND_END---");
    if (!frontend || !backend) {
      console.warn("Primary marker extraction failed. Trying legacy fallbacks.");
      if (!frontend) {
        const frontMatch = cleaned.match(/---frontend(?:\/index\.html)?---\s*([\s\S]*?)(?:---backend|$)/i);
        if (frontMatch) frontend = frontMatch[1].trim();
      }
      if (!backend) {
        const backMatch = cleaned.match(/---backend(?:\/server\.js)?---\s*([\s\S]*)/i);
        if (backMatch) backend = backMatch[1].trim();
      }
    }
    if (!frontend && cleaned.includes("<!DOCTYPE html")) {
      frontend = cleaned.slice(cleaned.indexOf("<!DOCTYPE html")).trim();
    }
    if (frontend && !/<!DOCTYPE html>/i.test(frontend)) {
      frontend = `<!DOCTYPE html>\n${frontend}`;
    }
    if (!frontend) {
      return res.status(502).json({
        error: "AI generation failed",
        details: "The AI did not return a complete frontend document. Please try again with a more specific prompt."
      });
    }
    db.query(
      "INSERT INTO generated_pages (prompt, code) VALUES (?, ?)",
      [prompt, frontend],
      (insertErr, insertRes) => {
        if (insertErr) {
          console.error("DB insert error:", insertErr);
        } else {
          console.log("Saved AI code entry id:", insertRes.insertId);
        }
      }
    );
    res.json({ frontendCode: frontend, backendCode: backend, raw: text });
  } catch (err) {
    console.error("AI generation error:", err);
    if (err && err.code === "AI_AUTH_FAILED") {
      return res.status(502).json({
        error: "AI provider configuration error",
        details: "One or more AI API keys are invalid or expired. Update the keys in backend/.env and try again."
      });
    }
    if (isQuotaError(err)) {
      const retryDelayMs = getRetryDelayMs(err);
      const retryAfterSeconds = retryDelayMs ? Math.ceil(retryDelayMs / 1000) : null;
      return res.status(429).json({
        error: "AI generation is temporarily unavailable",
        details: retryAfterSeconds
          ? `Gemini API quota is exhausted right now. Please wait about ${retryAfterSeconds} seconds and try again.`
          : "Gemini API quota is exhausted for this API key. Please check your plan, billing, or try again later.",
        retryAfterSeconds
      });
    }
    res.status(500).json({
      error: "AI generation failed",
      details: err && err.message ? err.message : "Unknown Gemini API error"
    });
  }
});
app.get("/history", (req, res) => {
  db.query("SELECT id, prompt, created_at FROM generated_pages ORDER BY id DESC", (err, rows) => {
    if (err) {
      console.error("DB select error:", err);
      return res.status(500).json({ error: "Failed to load history" });
    }
    res.json(rows);
  });
});
app.get("/history/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT id, prompt, code, created_at FROM generated_pages WHERE id = ?", [id], (err, rows) => {
    if (err) {
      console.error("DB select error:", err);
      return res.status(500).json({ error: "Failed to load entry" });
    }
    if (!rows.length) {
      return res.status(404).json({ error: "Not found" });
    }
    res.json(rows[0]);
  });
});
// simple health check
app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "ai-frontend-builder-backend" });
});
app.get("/", (_req, res) => {
  res.json({
    message: "AI Frontend Builder backend is running",
    health: "/health",
    generate: "/generate-ai"
  });
});
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


